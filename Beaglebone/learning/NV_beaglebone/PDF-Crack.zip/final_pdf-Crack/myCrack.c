#include "BeagleBone_gpio.h"
#include "BeagleBone_hd44780.h"

int main()
{
	int cracked_password=0;
	struct gpioID BUTTON1;
	pinMode(&BUTTON1,P9_12,"in");

	//specifies the pins that will be used on the LCD screen
	int selectedPins[]={P8_14,P8_12,P8_11,P8_5,P8_4,P8_3};

	struct gpioID enabled_gpio[6];		
	initialize_Screen(enabled_gpio,selectedPins);		
	clear_Screen(enabled_gpio);

	stringToScreen("Insert USB disk",enabled_gpio);
	goto_ScreenLine(1,enabled_gpio);
	stringToScreen("and press button",enabled_gpio);

	terminate_Screen(enabled_gpio,selectedPins);

	//while the BeagleBone is powered, this loop will never terminate	
	while(cracked_password==0)
	{

		//if button was pressed, make many system calls that
		//will mount the disk and start the cracking process
		if (digitalRead(BUTTON1)==0)
		{
			system("mkdir -p /mnt/usbdisk");
			system("mount /dev/sda1 /mnt/usbdisk");
			system("./pdfcrack /mnt/usbdisk/encrypted.pdf");
			system("umount /dev/sda1");

			cracked_password=1;			
			//after cracking is done, it will wait here until 
			//the user presses the button again
			while(digitalRead(BUTTON1)==0){};
		}
	}
	
	cleanup(BUTTON1);
	
	return 1;
}